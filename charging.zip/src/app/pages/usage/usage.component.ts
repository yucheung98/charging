import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usage',
  templateUrl: './usage.component.html',
  styleUrls: ['./usage.component.css']
})
export class UsageComponent implements OnInit {
  selectedDatetime: string;
  datetimelist: any = [
    '2020-05-22',
    '2020-05-24',
    '2020-05-25',
    '2020-05-26',
    '2020-05-27',
    '2020-05-28',
    '2020-05-29',
    '2020-05-30',
    '2020-05-31'
  ];
  // tslint:disable-next-line:variable-name
  option_company1: {};
  // tslint:disable-next-line:variable-name
  option_company2: {};
  listOfData = [
    {
      company: '国网沈阳供电公司',
      amount: 1582.7499999999998,
      dur: 277.22139999999996,
      times: 110,
      usage: 1336.62
    },
    {
      company: '国网大连供电公司',
      amount: 1582.7499999999998,
      dur: 277.22139999999996,
      times: 110,
      usage: 1336.62
    },
    {
      company: '国网铁岭供电公司',
      amount: 1582.7499999999998,
      dur: 277.22139999999996,
      times: 110,
      usage: 1336.62
    },
    {
      company: '国网营口供电公司',
      amount: 1582.7499999999998,
      dur: 277.22139999999996,
      times: 110,
      usage: 1336.62
    },
    {
      company: '国网鞍山供电公司',
      amount: 1582.7499999999998,
      dur: 277.22139999999996,
      times: 110,
      usage: 1336.62
    },
    {
      company: '国网朝阳供电公司',
      amount: 1582.7499999999998,
      dur: 277.22139999999996,
      times: 110,
      usage: 1336.62
    },
    {
      company: '国网锦州供电公司',
      amount: 1582.7499999999998,
      dur: 277.22139999999996,
      times: 110,
      usage: 1336.62
    },
    {
      company: '国网抚顺供电公司',
      amount: 1582.7499999999998,
      dur: 277.22139999999996,
      times: 110,
      usage: 1336.62
    },
    {
      company: '国网本溪供电公司',
      amount: 1582.7499999999998,
      dur: 277.22139999999996,
      times: 110,
      usage: 1336.62
    },
    {
      company: '国网丹东供电公司',
      amount: 1582.7499999999998,
      dur: 277.22139999999996,
      times: 110,
      usage: 1336.62
    }

  ];
  onSubmitDatetime(paramSearch) {
    console.log(paramSearch);
  }
  constructor() { }

  ngOnInit() {
    this.option_company1 = {
      // color: ['#07c2d3',  '#99cc33'],
      title: {
        // text: '辽宁省GDP发展趋势'
      },
      tooltip : {
        trigger: 'axis',
        axisPointer : {
          type : 'shadow'
        }
      },
      legend: {
        // right : '15%',
        y: '20px',
        data: ['用电量(千瓦时)', '消费金额（元）']
      },
      grid: {
        left: '6%',
        right: '6%',
        bottom: '4%',
        containLabel: true
      },
      xAxis:  {
        type: 'category',
        // name: '季度',
        nameLocation: 'middle',
        nameGap: 30,
        splitLine: {
          show: false
        },
        axisLabel: {
          interval: 1
        },
        data: [
          '2020-05-22',
          '2020-05-24',
          '2020-05-25',
          '2020-05-26',
          '2020-05-27',
          '2020-05-28',
          '2020-05-29',
          '2020-05-30',
          '2020-05-31'
        ]
      },
      yAxis: [
        {
          type: 'value',
          // name: '用电量(千瓦时)',
          nameLocation: 'middle',
          nameGap: 50,
          min: 800,
          max: 1500,
          interval: 100,
          axisLabel: {
            formatter: '{value}'
          },
          splitLine: {
            show: false
          }
        },
        {
          type: 'value',
          // name: '消费金额（元）',
          nameLocation: 'middle',
          nameGap: 40,
          min: 1000,
          max: 2000,
          interval: 200,
          axisLabel: {
            formatter: '{value}'
          },
          splitLine: {
            show: false
          }
        },
      ],
      series: [
        {
          name:  '用电量(千瓦时)',
          type: 'line',
          smooth: true,
          // type: 'bar',
          // barWidth: '50%',
          // tslint:disable-next-line:max-line-length
          data: [1336.62,	1305.59,	1386.17,	1342.4,	1408.00,	976.79,	1286.37,	1325.82,	1443.85]
        },
        {
          name: '消费金额（元）',
          type: 'line',
          smooth: true,
          yAxisIndex: 1,
          // tslint:disable-next-line:max-line-length
          data: [1582.74,	1554.56,	1617.79,	1595.32,	1696.59,	1154.40,	1538.47,	1624.42,	1773.63]
        },
      ]
    };
    this.option_company2 = {
      // color: ['#07c2d3',  '#99cc33'],
      title: {
        // text: '辽宁省GDP发展趋势'
      },
      tooltip : {
        trigger: 'axis',
        axisPointer : {
          type : 'shadow'
        }
      },
      legend: {
        // right : '15%',
        y: '20px',
        data: ['用电量(千瓦时)', '消费金额（元）']
      },
      grid: {
        left: '6%',
        right: '6%',
        bottom: '4%',
        containLabel: true
      },
      xAxis:  {
        type: 'category',
        // name: '季度',
        nameLocation: 'middle',
        nameGap: 30,
        splitLine: {
          show: false
        },
        axisLabel: {
          interval: 1
        },
        data: [
          '2020-05-22',
          '2020-05-24',
          '2020-05-25',
          '2020-05-26',
          '2020-05-27',
          '2020-05-28',
          '2020-05-29',
          '2020-05-30',
          '2020-05-31'
        ]
      },
      yAxis: [
        {
          type: 'value',
          // name: '用电量(千瓦时)',
          nameLocation: 'middle',
          nameGap: 50,
          min: 800,
          max: 1500,
          interval: 100,
          axisLabel: {
            formatter: '{value}'
          },
          splitLine: {
            show: false
          }
        },
        {
          type: 'value',
          // name: '消费金额（元）',
          nameLocation: 'middle',
          nameGap: 40,
          min: 1000,
          max: 2000,
          interval: 200,
          axisLabel: {
            formatter: '{value}'
          },
          splitLine: {
            show: false
          }
        },
      ],
      series: [
        {
          name:  '用电量(千瓦时)',
          type: 'line',
          smooth: true,
          // type: 'bar',
          // barWidth: '50%',
          // tslint:disable-next-line:max-line-length
          data: [1336.62,	1305.59,	1386.17,	1342.4,	1408.00,	976.79,	1286.37,	1325.82,	1443.85]
        },
        {
          name: '消费金额（元）',
          type: 'line',
          smooth: true,
          yAxisIndex: 1,
          // tslint:disable-next-line:max-line-length
          data: [1582.74,	1554.56,	1617.79,	1595.32,	1696.59,	1154.40,	1538.47,	1624.42,	1773.63]
        },
      ]
    };
  }

}
